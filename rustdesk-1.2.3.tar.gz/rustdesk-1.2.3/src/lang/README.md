the template is in template.rs<BR>
transfer to **.rs<BR>
in format:<BR>
("ENG-KEY", "translation"),
